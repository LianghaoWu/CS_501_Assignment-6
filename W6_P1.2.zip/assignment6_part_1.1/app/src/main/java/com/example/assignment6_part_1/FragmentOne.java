package com.example.assignment6_part_1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class FragmentOne extends Fragment {

    public interface OnDataTransmissionListener {
        public void dataTransmission(String data);
    }

    private Button btnSend;
    private EditText messageSend;
    private OnDataTransmissionListener mListener;


    public void setOnDataTransmissionListener (OnDataTransmissionListener mListener) {
        this.mListener = mListener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_one, container, false);

        btnSend = (Button) v.findViewById(R.id.btnSent);
        messageSend = (EditText) v.findViewById(R.id.messageSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FragmentTwo fragment2 = (FragmentTwo) getActivity().getSupportFragmentManager().findFragmentByTag("fragment2");
//                fragment2.setData(messageSend.getText().toString());
                if (mListener != null) {
                    mListener.dataTransmission(messageSend.getText().toString());
                }
            }
        });

        return v;
    }
}