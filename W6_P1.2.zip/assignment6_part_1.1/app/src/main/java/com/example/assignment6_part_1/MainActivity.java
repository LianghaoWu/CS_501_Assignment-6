package com.example.assignment6_part_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentOne fragment1 = new FragmentOne();
        FragmentTwo fragment2 = new FragmentTwo();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment1, fragment1, "fragment1").commit();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment2, fragment2, "fragment2").commit();

        fragment1.setOnDataTransmissionListener(new FragmentOne.OnDataTransmissionListener() {
            @Override
            public void dataTransmission(String data) {
                fragment2.setData(data);
            }
        });
    }
}